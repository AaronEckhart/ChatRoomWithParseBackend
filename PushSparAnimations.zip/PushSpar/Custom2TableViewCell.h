//
//  Custom2TableViewCell.h
//  PushSpar
//
//  Created by AE on 6/18/14.
//  Copyright (c) 2014 Aaron Eckhart. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Custom2TableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageInCell;
@property (weak, nonatomic) IBOutlet UILabel *usernameLabelInCell;
@property (weak, nonatomic) IBOutlet UITextView *commentTextView;
@property (weak, nonatomic) IBOutlet UILabel *commentTextLabel;

@end
