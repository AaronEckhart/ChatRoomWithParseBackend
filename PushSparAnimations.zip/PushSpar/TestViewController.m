//
//  TestViewController.m
//  PushSpar
//
//  Created by AE on 6/20/14.
//  Copyright (c) 2014 Aaron Eckhart. All rights reserved.
//

#import "TestViewController.h"

@interface TestViewController ()

@property UIPushBehavior *pushBehavior;
@property UIGravityBehavior *gravityBehavior;
@property UIDynamicAnimator *dynamicAnimator;
@property UICollisionBehavior *collisionBehavior;


@property (strong, nonatomic) IBOutlet UIImageView *views;

@end

@implementation TestViewController



- (void)viewDidLoad
{
    [super viewDidLoad];


    self.dynamicAnimator = [[UIDynamicAnimator alloc] initWithReferenceView:self.views];
    self.gravityBehavior = [[UIGravityBehavior alloc] initWithItems:@[self.views]];
    //self.collisionBehavior = [[UICollisionBehavior alloc] initWithItems:@[self.view]];
//    self.collisionBehavior = [[UICollisionBehavior alloc] initWithItems:@[self.viewt]];

  //  self.collisionBehavior.translatesReferenceBoundsIntoBoundary = NO;

    [self.dynamicAnimator addBehavior:self.gravityBehavior];
    //[self.dynamicAnimator addBehavior:self.collisionBehavior];


    self.gravityBehavior.magnitude = 0.9;}



@end
